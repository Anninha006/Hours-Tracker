var mysql = require('mysql');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "hours_tracker"
});
con.connect(function (err) {
    if (err) throw err;
    console.log("Conectado!");


    
    /* Tabelas: horas complementares, posts, e usuario_atividade  */
    var tipoAtividade = "CREATE TABLE tipo_atividade (id_tipo_atividade INT AUTO_INCREMENT PRIMARY KEY, tipo_atividade VARCHAR(500), hora_max INT, hora_atividade INT, id_curso INT, FOREIGN KEY (id_curso) REFERENCES cursos(id_curso))";
    con.query(tipoAtividade, function (err, result) {
        if (err) throw err;
        console.log("Tabela tipo_atividade criada");

        if (err) throw err;
        var insereDados = "INSERT INTO tipo_atividade (id_curso, tipo_atividade, hora_max, hora_atividade) VALUES ?";
        var values = [
            [1,'Projetos e Programas de pesquisa', '40', '10'],
            [1,'Atividades em programas e projetos de extensão', '40', '5'],
            [1,'Participação em eventos técnicos científicos', '40', '2'],
            [1,'Atividades de monitorias em disciplinas de curso', '50', '30'],
            [1,'Estudos em disciplinas que não integram o currículo do curso e/ou disciplinas de outros cursos', '40', '20'],
            [1,'Participação em cursos de curta duração', '40', '2'],
            [1,'Trabalhos publicados em revistas, etc. / apresentação em eventos científicos e aprovação ou premiação em concursos', '30', '10'],
            [1,'Atividades de gestão', '40', '10'],
            [1,'Estágio extracurricular na área do curso', '50', '30'],
            [1,'Participação em projeto de ensino', '40', '10'],
            [1,'Representante discente no Conselho Superior do IFSul', '20', '20'],
            [1,'Participação em palestras', '30', '1'],
            [1,'Participação na Semana Acadêmica do curso', '40', '8'],
            [1,'Curso de tecnologia na área de Informática', '40', '6'],
            [1,'Curso de idiomas', '30', '20'],
        ];
        con.query(insereDados, [values], function (err, result) {
            if (err) throw err;
            console.log("Numero de registros inseridos: " + result.affectedRows);
        });

        var sql = "CREATE TABLE usuario_atividade (id_usuario_ativ INT AUTO_INCREMENT PRIMARY KEY, id_usuario INT, FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario), id_atividade INT, FOREIGN KEY (id_atividade) REFERENCES tipo_atividade(id_tipo_atividade), ch_sugerida FLOAT, status VARCHAR(15), ch_enviada FLOAT,certificado VARCHAR(255), nome_atividade VARCHAR(255), ch_deferida FLOAT, mensagem VARCHAR(255))";
        con.query(sql, function (err, result) {
            if (err) throw err;
            console.log("Tabela de horas complementares criada");
        });

        con.query("USE hours_tracker", function (err, result) {
            if (err) throw err;
            var sugestaoHoras = "CREATE TABLE sugestao_horas (id_usuario INT, FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario), id_post INT AUTO_INCREMENT PRIMARY KEY, titulo_post VARCHAR(255), imagem_post VARCHAR(255), texto_post text, status_revisao VARCHAR(10), data_post DATETIME DEFAULT CURRENT_TIMESTAMP)";
            con.query(sugestaoHoras, function (err, result) {
                if (err) throw err;
                console.log("Tabela de posts criada");


                var inserirPost = "INSERT INTO sugestao_horas (id_usuario, titulo_post, imagem_post, texto_post, status_revisao) VALUES ?";
                var postValues = [
                    [2,
                        'Cursos online e gratuitos disponibilizados pelo IFSul',
                        'ifmundi.png',
                        'Mundi, plataforma de cursos online e gratuitos do IFSul, na qual são oferecidos cursos no formato Massive Open Online Courses (Mooc), que em português significa "cursos online abertos e massivos". O objetivo é levar conhecimento à comunidade, acadêmica e externa, de forma totalmente gratuita e online.\nNo momento estão disponíveis 16 cursos, mas o catálogo de ofertas será constantemente atualizado de acordo com a demanda da comunidade. Os cursos são de inscrição livre para qualquer pessoa e possuem certificação. Para isso, o estudante deverá atingir, no mínimo, a nota seis em todas as atividades exigidas.\nOs cursos disponibilizados na Mundi são de autoria de servidores de diversas áreas do IFSul. Segundo o Pró-reitor de ensino do IFSul, Rodrigo Nascimento, a plataforma vai permitir que outros servidores também possam produzir seus cursos MOOC e ofertá-los pelo sistema, através de um fluxo de procedimentos que a Pró-reitoria de Ensino (Proen) vai desenvolver. \'Isso mostra um enorme ganho para instituição, pois os colegas poderão socializar seus conhecimentos para um contingente enorme de pessoas\', avalia Rodrigo.\nPara o Chefe do Departamento de Educação a Distância e Novas Tecnologias, Antônio Oliveira, a Plataforma Mundi vem como uma nova frente de trabalho, \'ampliando assim as modalidades de cursos EaD já oferecidos pelo IFSul, ao longo dos mais de dez anos de EaD, capacitando cada vez mais pessoas\'.',
                        'Válido'
                    ]
                ];

                con.query(inserirPost, [postValues], function (err, result) {
                    if (err) throw err;
                    console.log("Post inserido com sucesso!");
                    con.end(); // Closing the database connection
                });
            });
        });
    });
    //con.end();
});
