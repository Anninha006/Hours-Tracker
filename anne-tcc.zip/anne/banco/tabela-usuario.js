var mysql = require('mysql');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "hours_tracker"
});
con.connect(function (err) {
    if (err) throw err;
    console.log("Conectado!");

    var tabelaCursos = "CREATE TABLE cursos (id_curso INT AUTO_INCREMENT PRIMARY KEY, nome_curso VARCHAR(255), nivel_curso VARCHAR(255), ch_necessaria INT)";
    con.query(tabelaCursos, function (err, result) {
        if (err) throw err;
        console.log("Tabela de cursos criada");

        var inserirCurso = "INSERT INTO cursos (nome_curso, nivel_curso, ch_necessaria) VALUES ?";
        var values = [
            ['Informática para Internet','Técnico', 60]
        ];
        con.query(inserirCurso, [values], function (err, result) {
            if (err) throw err;
            console.log("Curso inserido com sucesso!");
        });

        var sql = "CREATE TABLE usuario (id_usuario INT AUTO_INCREMENT PRIMARY KEY, nome_usuario VARCHAR(255), email VARCHAR(255), foto_perfil VARCHAR(255), tipo_usuario INT, id_curso INT, FOREIGN KEY (id_curso) REFERENCES cursos(id_curso))";
    con.query(sql, function (err, result) {
        if (err) throw err;
        console.log("Tabela usuario criada");

        // var sugestaoHoras = "CREATE TABLE sugestao_horas (id_usuario INT, FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario), id_post INT AUTO_INCREMENT PRIMARY KEY, titulo_post VARCHAR(255), imagem_post VARCHAR(255), texto_post text, status_revisao VARCHAR(10), data_post DATETIME DEFAULT CURRENT_TIMESTAMP)";
        // con.query(sugestaoHoras, function (err, result) {
        //     if (err) throw err;
        //     console.log("Tabela de posts criada");
        //     con.end();
        // });

        chat = "CREATE TABLE chat (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, enviou_id INT , FOREIGN KEY (enviou_id) REFERENCES usuario(id_usuario), mensagem VARCHAR(255), recebeu_id INT, FOREIGN KEY (recebeu_id) REFERENCES usuario(id_usuario), data DATETIME DEFAULT CURRENT_TIMESTAMP, lida TINYINT)";
        con.query(chat, function (err, result) {
            if (err) throw err;
            console.log("Tabela chat criada");
        });
    });


    var valores = [
        ["Anne Santos", "annesantosdasilva06@gmail.com", 2, 1],
        ["Anne Santos da Silva", "annesilva.gr007@academico.ifsul.edu.br", 3, 1],
        ["Denise Matos", "denimatossantos@gmail.com", 1, 1]
    ];

    var sql = "INSERT INTO usuario (nome_usuario, email, tipo_usuario, id_curso) VALUES ?";
    con.query(sql, [valores], function (err, result) {
        if (err) throw err;
        console.log("Valores inseridos na tabela usuario");
    });

    });

    /* Tabelas: usuario com valores principais definidos e chat  */
        // con.end();
});
