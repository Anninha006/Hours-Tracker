const mysql = require('mysql');
const formidable = require('formidable');
const fs = require('fs');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const path = require('path');
const saltRounds = 10;
var express = require('express');
var app = express();
const moment = require('moment');
const reader = require('xlsx');
const session = require('express-session');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "hours_tracker"
});
con.connect(function (err) {
    if (err) throw err;
    console.log("Conectado!");
});

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }))
app.set('view engine', 'ejs');
const passport = require('passport');

const MySQLStore = require('express-mysql-session')(session);
app.use(session({
    store: new MySQLStore({
        host: 'localhost', port: '3306', user: "root", password: "",
        database: "hours_tracker"
    }),
    secret: '2C44-4D44-WppQ38S',//configure um segredo seu aqui,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 30 * 60 * 1000 }//30min
}))
app.use(passport.initialize());
app.use(passport.session())

var GoogleStrategy = require('passport-google-oauth2').Strategy;
passport.use(new GoogleStrategy({
    clientID: '828253764798-tc7p7qtjhkmladcqocsie7n2cak18dne.apps.googleusercontent.com',
    clientSecret: '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',
    callbackURL: "http://localhost:3000/auth/google/callback",
    passReqToCallback: true,
    userProfileURL: 'https://www.googleapis.com/oauth2/v3/userinfo', // Adicione esta linha
    scope: ['profile', 'email'] // Adicione 'email' ao escopo
},
    function (request, accessToken, refreshToken, profile, done) {
        return done(null, profile);
    }
));
passport.serializeUser((user, done) => {
    done(null, { id_usuario: user.id, nome_usuario: user.displayName, foto_usuario: user.picture, logado: true, tipo_usuario: tipo_usuario, email: email }); // email: user.email 
})
passport.deserializeUser((user, done) => {
    done(null, user)
})

app.use(function (req, res, next) {
    res.locals.logado = req.session.logado;
    res.locals.foto = req.session.foto;
    res.locals.id_usuario = req.session.id_usuario;
    res.locals.nome = req.session.nome;
    res.locals.email = req.session.email;
    res.locals.tipo_usuario = req.session.tipo_usuario;
    res.locals.id_curso = req.session.id_curso;
    next();
})
const users = [
    { id: 1, username: 'annesantosdasilva06@gmail.com', role: 'admin' }, //'2'
    { id: 2, username: 'denimatossantos@gmail.com', role: 'secretaria' }, //'3'
    { id: 3, username: 'annesilva.gr007@academico.ifsul.edu.br', role: 'aluno' }, //'1 '
];

// // Middleware para verificar se o usuário tem permissão de administrador
const isAdmin = (req, res, next) => {
    // if (req.isAuthenticated() && req.user.role === 'admin') {
    if (req.session.logado && req.session.tipo_usuario === 'admin') {
        return next();
    } else {
        res.redirect('/');
    }
};

const isSecretaria = (req, res, next) => {
    if (req.session.logado && req.session.tipo_usuario === 'secretaria') {
        return next();
    } else {
        res.redirect('/');
    }
};

const isAdm_Sec = (req, res, next) => {
    if (req.session.logado && req.session.tipo_usuario === 'admin' || req.session.logado && req.session.tipo_usuario === 'secretaria') {
        return next();
    } else {
        res.redirect('/');
    }
};

const isAluno = (req, res, next) => {
    if (req.session.logado && req.session.tipo_usuario === 'aluno') {
        return next();
    } else {
        res.redirect('/');
    }
};

app.get("/auth/google", passport.authenticate("google", {
    scope:
        ["profile"]
}));
app.get('/auth/google/callback', (req, res, next) => {
    passport.authenticate("google", { failureRedirect: "/erro" }, async (error, user, info) => {
        if (error) {
            res.send(error);
        }
        if (user) {
            con.query('SELECT * FROM usuario WHERE nome_usuario = ?', user.displayName, async function (err, result) {
                if (err) throw err;
                //console.log(user)
                //console.log(result)
                if (result.length) {
                    req.session.id_usuario = result[0].id_usuario;
                    req.session.nome_usuario = user.displayName;
                    req.session.logado = true;
                    req.session.email = result[0].email;
                    req.session.id_curso = result[0].id_curso;
                    var tipo_usuario;
                    if (result[0].tipo_usuario === 2) {
                        tipo_usuario = 'admin';
                    } else if (result[0].tipo_usuario === 3) {
                        tipo_usuario = 'secretaria';
                    } else {
                        tipo_usuario = 'aluno';
                    }
                    req.session.tipo_usuario = tipo_usuario;
                    // Verifica se há foto de perfil cadastrada no banco de dados
                    if (result[0]['foto_perfil']) {
                        req.session.foto = result[0]['foto_perfil'];
                    } else {
                        // Se não houver foto de perfil cadastrada, use a foto do Google
                        req.session.foto = user.picture;
                        // Salva a foto do perfil do Google no banco de dados
                        con.query('UPDATE usuario SET foto_perfil = ? WHERE nome_usuario = ?', [user.picture, user.displayName], function (err, result) {
                            if (err) throw err;
                            console.log('Foto do perfil do Google salva no banco de dados.');
                        });
                    }
                    res.redirect('/');
                } else {
                    res.redirect('/contato');
                }
            });
        }
    })(req, res, next);
});

// Página Principal
app.get('/', function (req, res) {
    var mensagem = null;
    if (req.session.mensagem) {
        mensagem = req.session.mensagem;
        req.session.mensagem = null;
    }
    res.render('index.ejs', { mensagem: mensagem });
});

// Logout
app.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err) {
            console.error("Erro:" + err);
        }
        res.redirect('/'); ///login
    });
});

app.get('/contato', function (req, res) {
    res.render('contato.ejs');
})


app.get('/cadastro-curso', isSecretaria, function (req, res) {
    if (req.session.id_usuario) {
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        res.render('cadastro-curso.ejs');
    } else {
        res.redirect('/login');
    }
});

app.post('/cadastro-curso', function (req, res) {
    var form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        var sql = "INSERT INTO cursos (nome_curso, nivel_curso, ch_necessaria) VALUES ?";
        var values = [[fields['nome_curso'], fields['nivel_curso'], fields['ch_necessaria']]];
        con.query(sql, [values], function (err, result) {
            if (err) throw err;
            console.log("Numero de registros inseridos: " + result.affectedRows);
            req.session.mensagem = "Curso inserido à tabela";
            res.redirect('/usuario');
        });
    });
});

app.get('/cadastro-tipo_ativ', isSecretaria, function (req, res) {
    if (req.session.id_usuario) {
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        con.query('SELECT * FROM cursos', function (err, rows) {
            if (err) throw err;
            res.render('cadastro-tipo_ativ.ejs', { tipoParaAtividade: rows, mensagem: mensagem, isLoggedIn: req.session.loggedin });
        });
    } else {
        res.redirect('/login');
    }
});

app.post('/cadastro-tipo_ativ', function (req, res) {
    var form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        var id_curso = fields['id_curso'];
        var sql = "INSERT INTO tipo_atividade (tipo_atividade, hora_max, hora_atividade, id_curso) VALUES (?,?,?,?) "; //where id_curso = ?
        var values = [fields['tipo_atividade'], fields['hora_max'], fields['hora_atividade'], id_curso];
        con.query(sql, values, function (err, result) {
            if (err) throw err;
            console.log("Numero de registros inseridos: " + result.affectedRows);
            req.session.mensagem = "Novos tipos de atividade inseridos à tabela";
            res.redirect('/usuario');
        });
    });
});


app.get('/cadastro', isSecretaria, function (req, res) {
    if (req.session.id_usuario) {
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        con.query('SELECT * FROM cursos', function (err, rows) {
            if (err) throw err;
            console.log(rows)
            res.render('cadastro.ejs', { tipoCurso: rows, mensagem: mensagem, isLoggedIn: req.session.loggedin });
        });
    } else {
        res.redirect('/login');
    }
});

app.post('/cadastro', function (req, res) {
    var form = new formidable.IncomingForm({ allowEmptyFiles: true, minFileSize: 0 });
    form.parse(req, (err, fields, files) => {
        if (err) throw err;

        if (fields.nome_usuario == 0 || fields.email == 0) {
            // Verificar se o arquivo foi enviado
            if (files['arquivo_xls'][0]['originalFilename'].length == 0) {
                req.session.mensagem = "Por favor, preencha o formulário ou envie um arquivo.";
                res.redirect('/cadastro')
                return;
            }
        }
        if (files['arquivo_xls'][0]['originalFilename'].length !== 0) {
            const oldpath = files.arquivo_xls[0].filepath;
            const newpath = path.join(__dirname, 'public/xlsx/', files['arquivo_xls'][0]['originalFilename']);
            fs.rename(oldpath, newpath, function (err) {
                if (err) throw err;
                const file = reader.readFile(newpath);
                let data = [];
                const sheets = file.SheetNames
                for (let i = 0; i < sheets.length; i++) {
                    const temp = reader.utils.sheet_to_json(file.Sheets[file.SheetNames[i]])
                    temp.forEach((res) => {
                        data.push(res)
                    })
                }
                var values = data.map(item => [item.Nome, item['Email Acadêmico'], fields['id_curso'][0], 1]);
                var sql = "INSERT INTO usuario (nome_usuario, email, id_curso, tipo_usuario) VALUES ?";
                con.query('SELECT * FROM usuario WHERE email = ?', [data[0]['Email Acadêmico']], function (err, result) {
                    if (err) throw err;
                    if (result.length > 0) {
                        req.session.mensagem = "Algum dos emails do arquivo enviado já foi cadastrado. Tente outro e-mail ou vá para a página de login.";
                        res.redirect('/cadastro');
                    } else {
                        con.query(sql, [values], function (err, result) {
                            if (err) throw err;
                            console.log("Numero de registros inseridos: " + result.affectedRows);
                            req.session.mensagem = "Cadastro realizado com sucesso! Numero de registros inseridos: " + result.affectedRows;
                            res.redirect('/cadastro');
                        });
                    }
                });
            });
        } else {
            con.query('SELECT * FROM usuario WHERE email = ?', [fields['email'][0]], function (err, result) {
                if (err) throw err;
                if (result.length > 0) {
                    mensagem = "E-mail já cadastrado. Tente outro e-mail ou vá para a página de login.";
                    res.render('/cadastro')
                } else {
                    var sql = "INSERT INTO usuario (nome_usuario, email, id_curso, tipo_usuario) VALUES ?";
                    var values = [[fields['nome_usuario'][0], fields['email'][0], fields['id_curso'][0], 1]];
                    con.query(sql, [values], function (err, result) {
                        if (err) throw err;
                        req.session.mensagem = "Numero de registros inseridos: " + result.affectedRows;
                        res.redirect('/cadastro');
                    });
                }
            });
        }
    });
});

// Página de usuário
app.get('/usuario', function (req, res) {
    if (req.session.id_usuario) { //id_usuario
        //console.log(req.session);
        var nome = req.session.nome_usuario;
        var id = req.session.id_usuario;
        var email = req.session.email;
        var id_curso = req.session.id_curso;
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        calcularHorasRestantesDoUsuario(id_curso, id, function (horasRestantes) {
            var selectSql = "SELECT SUM(ch_deferida) AS total_ch_deferida FROM usuario_atividade WHERE id_usuario = ? && status = ?";
            con.query(selectSql, [id, "Deferido"], function (err, result) {
                if (err) throw err;
                var totalChDeferida = result[0].total_ch_deferida || 0;
                res.render('usuario.ejs', { nome, id, email, totalChDeferida, horasRestantes, mensagem: mensagem });
            });
        });
    } else {
        res.redirect('/login');
    }
});

function calcularHorasRestantesDoUsuario(id_curso, idUsuario, callback) {
    // var id_curso = req.session.id_curso;
    var selectSql = "SELECT SUM(ch_deferida) AS total_ch_deferida FROM usuario_atividade WHERE id_usuario = ? && status = ?";
    con.query(selectSql, [idUsuario, "Deferido"], function (err, result) {
        if (err) throw err;
        var totalChDeferida = result[0].total_ch_deferida || 0;
        console.log("Horas complementares deferidas para o usuário " + idUsuario + ": " + totalChDeferida);

        var necessaria = "SELECT ch_necessaria as horasNecessarias FROM cursos WHERE id_curso = ?";
        con.query(necessaria, [id_curso], function (err, resultCurso) {
            if (err) throw err;
            var horasTotaisNecessarias = resultCurso[0].horasNecessarias;

            var horasRestantes = horasTotaisNecessarias - totalChDeferida;
            console.log("Horas complementares restantes para o usuário " + idUsuario + ": " + horasRestantes);
            callback(horasRestantes);
        });
    });
}

app.get('/login', function (req, res) {
    res.redirect('auth/google');
})

//Editar usuário (terceiro)
app.get('/edita-usuario/:id_usuario', isAdmin, function (req, res) {
    if (req.session.id_usuario) {
        var sql = "SELECT nome_usuario, foto_perfil, id_usuario FROM usuario where id_usuario= ?";
        var id_usuario = req.params.id_usuario;
        con.query(sql, id_usuario, function (err, result, fields) {
            if (err) throw err;
            // console.log(result)
            res.render('edita-usuario.ejs', { dadosUsuario: result });
        });
    } else {
        res.redirect('/login');
    }
});

app.post('/edita-usuario/:id_usuario', function (req, res) {
    // console.log('edita')
    var form = new formidable.IncomingForm();
    form.options.allowEmptyFiles = true; // permitir o envio opcional 
    form.options.minFileSize = 0; // permitir o envio opcional
    form.parse(req, (err, fields, files) => {
        if (err) throw err;
        // console.log(files['foto_perfil'])
        if (files['foto_perfil'][0]['originalFilename'].length !== 0) {
            var oldpath = files.foto_perfil[0].filepath;
            var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
            var nomeimg = hash + '.' + files.foto_perfil[0].mimetype.split('/')[1]
            var newpath = path.join(__dirname, 'public/imagens/usuario/', nomeimg);
            fs.rename(oldpath, newpath, function (err) {
                if (err) throw err;
            });
            var id_usuario = req.params.id_usuario;
            var sql = "UPDATE usuario SET nome_usuario = ?, foto_perfil = ? WHERE id_usuario = ?";
            var values = [fields['nome_usuario'], nomeimg, id_usuario];
        } else {
            //console.log('else')
            var sql = "UPDATE usuario SET nome_usuario = ? WHERE id_usuario = ?";
            var values = [fields['nome_usuario'], id_usuario];
        }
        con.query(sql, values, function (err, result) {
            if (err) throw err;
            console.log("Numero de registros alterados: " + result.affectedRows);
            req.session.mensagem = "Dados do usuário alterados com sucesso!";
            res.redirect('/usuarios');
        });
    });
});

//Edita perfil próprio:
app.get('/edita-perfil/:id_usuario', function (req, res) {
    if (req.session.id_usuario) {
        var sql = "SELECT nome_usuario, foto_perfil, id_usuario FROM usuario where id_usuario= ?";
        var id_usuario = req.session.id_usuario;
        con.query(sql, id_usuario, function (err, result, fields) {
            if (err) throw err;
            // console.log(result)
            res.render('edita-perfil.ejs', { dadosUsuario: result });
        });
    } else {
        res.redirect('/login');
    }
});

app.post('/edita-perfil/:id_usuario', function (req, res) {
    // console.log('edita')
    var form = new formidable.IncomingForm();
    form.options.allowEmptyFiles = true; // permitir o envio opcional 
    form.options.minFileSize = 0; // permitir o envio opcional
    form.parse(req, (err, fields, files) => {
        if (err) throw err;
        if (files['foto_perfil'][0]['originalFilename'].length !== 0) {
            var oldpath = files.foto_perfil[0].filepath;
            var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
            var nomeimg = hash + '.' + files.foto_perfil[0].mimetype.split('/')[1]
            var newpath = path.join(__dirname, 'public/imagens/usuario/', nomeimg);
            fs.rename(oldpath, newpath, function (err) {
                if (err) throw err;
            });
            var id_usuario = req.session.id_usuario;
            var sql = "UPDATE usuario SET nome_usuario = ?, foto_perfil = ? WHERE id_usuario = ?";
            var values = [fields['nome_usuario'], nomeimg, id_usuario];
            req.session.foto = nomeimg;
        } else {
            var id_usuario = req.session.id_usuario;
            var sql = "UPDATE usuario SET nome_usuario = ? WHERE id_usuario = ?";
            var values = [fields['nome_usuario'], id_usuario];
            req.session.nome_usuario = fields['nome_usuario'];
        }
        con.query(sql, values, function (err, result) {
            if (err) throw err;
            console.log("Numero de registros alterados: " + result.affectedRows);
            req.session.nome = fields['nome_usuario'];
            req.session.mensagem = "Dados alterados com sucesso";
            res.redirect('/usuario');
        });
    });
});

// Cadastrar certificado
app.get('/cadastro-horas', isAluno, function (req, res) {
    if (req.session.id_usuario) {
        var id_curso = req.session.id_curso;
        con.query('SELECT id_tipo_atividade, tipo_atividade FROM tipo_atividade WHERE id_curso = ?', [id_curso], function (err, rows) { // WHERE id_curso = ?', [usuario.id_curso], function
            if (err) throw err;
            res.render('cadastro-horas.ejs', { tipoAtividades: rows, id_curso });
        });
    } else {
        res.redirect('/login');
    }
});

async function inserirNoBanco(tipo, nome, qtd_horas, oldpath, nomeimg, id_usuario) {
    con.query('SELECT hora_max, hora_atividade FROM tipo_atividade WHERE id_tipo_atividade = ?', [tipo], function (err, result) {
        if (err) throw err;
        var hora_max = result[0].hora_max;
        var hora_atividade = result[0].hora_atividade;
        con.query('SELECT SUM(ch_sugerida) as soma FROM `usuario_atividade` WHERE id_atividade = ? and status != "Indeferido" and id_usuario = ?', [tipo, id_usuario], function (err, result2) {
            if (err) throw err;
            var soma = 0
            // console.log(result2)
            if (result2[0].soma)
                soma = result2[0].soma;

            var ch_sugerida = 0;
            var horas_enviadas = qtd_horas;
            var enviadas_soma = parseInt(horas_enviadas, 10) + parseInt(soma, 10);
            var atividade_soma = parseInt(hora_atividade, 10) + parseInt(soma, 10)
            if (soma >= hora_max) {
                //console.log("Já passou das horas permitidas")
                ch_sugerida = 0;
            } else {
                if (horas_enviadas < hora_atividade) {
                    //  console.log("horas_enviadas < hora_atividade")
                    if (enviadas_soma > hora_max) {
                        //    console.log("horas_enviadas + soma > hora_max")
                        ch_sugerida = hora_max - soma;
                    }
                    else {
                        //  console.log("horas_enviadas + soma < hora_max")
                        ch_sugerida = horas_enviadas;
                    }
                } else {
                    //console.log("horas_enviadas > hora_atividade")
                    if (atividade_soma > hora_max) {
                        //console.log("hora_atividade + soma> hora_max")
                        ch_sugerida = hora_max - soma;
                    } else {
                        //  console.log("hora_atividade + soma < hora_max")
                        ch_sugerida = hora_atividade;
                    }
                }
            }
            newpath = path.join(__dirname, 'public/arquivos/', nomeimg);
            fs.renameSync(oldpath, newpath);
            var sql = "INSERT INTO usuario_atividade (id_usuario, id_atividade, nome_atividade, ch_sugerida, status, ch_enviada, ch_deferida, certificado) VALUES ?";
            var values = [[id_usuario, tipo, nome, ch_sugerida, "Pendente", horas_enviadas, 0, nomeimg]];
            con.query(sql, [values], function (err, result) {
                if (err) throw err;
                console.log("Número de registros inseridos: " + result.affectedRows);
            });
        });
    });
}
const delayExecution = (ms) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve()
        }, ms)
    })
}

app.post('/cadastro-horas', async function (req, res) {
    var id_usuario = req.session.id_usuario;
    var form = new formidable.IncomingForm();
    form.parse(req, async (err, fields, files) => {
        if (err) throw err;
        // Captura o tipo de atividade selecionado
        var tipo = fields['tipo_atividade'];
        var condicao = true;
        var n = 0;
        while (condicao) {
            var nome = n == 0 ? fields['nome_atividade'] : fields['nome_atividade' + n];
            var qtd_horas = n == 0 ? fields['qtd_horas'] : fields['qtd_horas' + n];
            var oldpath = n == 0 ? files.certificado[0].filepath : files['certificado' + n][0].filepath;
            hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
            nomeimg = n == 0 ? hash + '.' + files.certificado[0].mimetype.split('/')[1] : hash + '.' + files['certificado' + n][0].mimetype.split('/')[1]
            await inserirNoBanco(tipo, nome, qtd_horas, oldpath, nomeimg, id_usuario);
            await delayExecution(1000)

            // console.log(n)
            n++;
            if (fields['tipo_atividade' + n] === undefined) {
                condicao = false;
            }
        }
        req.session.mensagem = "Certificado(s) enviado para avaliação";
        res.redirect('/listar-horas-aluno');
    });
});

// Listar certificados (individual)
app.get('/listar-horas-aluno', isAluno, function (req, res) {
    if (req.session.id_usuario) {
        var id_usuario = req.session.id_usuario;
        var sql = "SELECT * FROM usuario_atividade WHERE id_usuario = ?";
        var values = [id_usuario];
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        con.query(sql, [values], function (err, result, fields) {
            if (err) throw err;
            //(result);
            // Buscar os tipos de atividade
            con.query('SELECT id_tipo_atividade, tipo_atividade FROM tipo_atividade', function (errTipo, tipoAtividades) {
                if (errTipo) throw errTipo;
                // Passando os tipos de atividade para a view junto com os outros dados
                res.render('horas-aluno.ejs', {
                    horasEnviadas: req.session.horas_enviadas,
                    mensagem: mensagem,
                    dadosCertificado: result,
                    tipoAtividades: tipoAtividades // Adicionando os tipos de atividade ao objeto de renderização
                });
            });
        });
    } else {
        res.redirect('/login');
    }
});


// Listagem de posts do aluno
app.get('/listar-post-aluno', isAluno, function (req, res) {
    if (req.session.id_usuario) {
        id_usuario = req.session.id_usuario;
        var sql = "SELECT * FROM sugestao_horas WHERE id_usuario = ?";
        var values = [id_usuario];
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        con.query(sql, [values], function (err, result, fields) {
            if (err) throw err;
            res.render('post-aluno.ejs', { mensagem: mensagem, dadosPost: result });
        });
    } else {
        res.redirect('/login');
    }
});

// Listar certificados (TODOS)
app.get('/listagem', isAdm_Sec, function (req, res) {
    if (req.session.id_usuario) {
        var sql = `SELECT usuario_atividade.*, usuario.nome_usuario, usuario.foto_perfil, usuario.id_usuario 
        FROM usuario_atividade 
        JOIN usuario ON usuario_atividade.id_usuario = usuario.id_usuario`;
        // var sql = "SELECT usuario_atividade.*, usuario.nome_usuario, usuario.foto_perfil FROM usuario_atividade JOIN usuario ON usuario_atividade.id_usuario = usuario.id_usuario";
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            // console.log(result);
            // Buscar os tipos de atividade
            con.query('SELECT id_tipo_atividade, tipo_atividade FROM tipo_atividade', function (errTipo, tipoAtividades) {
                if (errTipo) throw errTipo;
                // Agora passamos os tipos de atividade para a view junto com os outros dados
                res.render('listar-horas.ejs', {
                    horasEnviadas: req.session.horas_enviadas,
                    mensagem: mensagem,
                    dadosCertificados: result,
                    tipoAtividades: tipoAtividades,  // Adicionando os tipos de atividade ao objeto de renderização
                    usuario: req.session.nome,  // Adicionando o nome do usuário
                    // id_usuario: req.session.id_usuario,  // Adicionando o ID do usuário
                    imagem: req.session.foto  // Adicionando a foto do perfil do usuário
                });
            });
        });
    } else {
        res.redirect('/login');
    }
});


async function AlterarAtividades(id_atividade, hora_max, hora_atividade, certificado, id_usuario) {
    await con.query('SELECT SUM(ch_sugerida) as soma FROM `usuario_atividade` WHERE id_atividade = ? and id_usuario_ativ != ? and status != "Indeferido" and id_usuario = ?', [id_atividade, certificado.id_usuario_ativ, id_usuario], async function (err, result3) {
        if (err) throw err;
        var soma = 0
        //console.log(result3)
        if (result3[0].soma)
            soma = result3[0].soma;
        var ch_sugerida = 0;
        var horas_enviadas = certificado.ch_enviada;
        var sugerida_antiga = certificado.ch_sugerida;

        var enviadas_soma = parseInt(horas_enviadas, 10) + parseInt(soma, 10);
        var atividade_soma = parseInt(hora_atividade, 10) + parseInt(soma, 10);
        //console.log("Horas enviadas: " + horas_enviadas)
        //console.log("Hora atividade: " + hora_atividade)

        //console.log("Soma: " + soma)

        //console.log("Enviadas soma: " + enviadas_soma)
        //console.log("atividade_soma " + atividade_soma)
        if (soma >= hora_max) {
            //console.log("Já passou das horas permitidas")
            ch_sugerida = 0;
        } else {
            if (horas_enviadas < hora_atividade) {
                //console.log("horas_enviadas < hora_atividade")
                if (enviadas_soma > hora_max) {
                    //  console.log("horas_enviadas + soma > hora_max")
                    ch_sugerida = hora_max - soma;
                }
                else {
                    //    console.log("horas_enviadas + soma < hora_max")
                    ch_sugerida = horas_enviadas;
                }
            } else {
                //  console.log("horas_enviadas > hora_atividade")
                if (atividade_soma > hora_max) {
                    //          console.log("hora_atividade + soma> hora_max")
                    ch_sugerida = hora_max - soma;
                } else {
                    //        console.log("hora_atividade + soma < hora_max")
                    ch_sugerida = hora_atividade;
                }
            }
        }
        //console.log("Sugeridas antiga " + sugerida_antiga)
        //console.log("Sugeridas: " + ch_sugerida)
        if (sugerida_antiga != ch_sugerida) {
            var updateSql = "UPDATE usuario_atividade SET ch_sugerida = ? WHERE id_usuario_ativ = ?";
            await con.query(updateSql, [ch_sugerida, certificado.id_usuario_ativ], async function (err, result4) {
                if (err) throw err;
                console.log("Número de registros atualizados: " + result4.affectedRows);
            });
        }
    });
}
async function AlterarAtividadesdoTipo(id_usuario_ativ, id_usuario) {
    var sql = "SELECT id_atividade FROM usuario_atividade WHERE id_usuario_ativ = ?";
    con.query(sql, [id_usuario_ativ], async function (err, result) {
        if (err) throw err;
        // console.log(result);
        if (result == null || result.length === 0) {
            console.log("Nenhum resultado encontrado para a consulta.");
            return;
        } else {
            var id_atividade = result[0].id_atividade;
            await con.query('SELECT hora_max, hora_atividade FROM tipo_atividade WHERE id_tipo_atividade = ?', [id_atividade], async function (err, result2) {
                if (err) throw err;

                var hora_max = result2[0].hora_max;
                var hora_atividade = result2[0].hora_atividade;
                var i = 0;
                var selectSql = "SELECT * FROM usuario_atividade WHERE id_atividade = ? AND id_usuario_ativ != ? AND status NOT IN ('Deferido', 'Indeferido') AND id_usuario = ?";
                await con.query(selectSql, [id_atividade, id_usuario_ativ, id_usuario], async function (err, certificados) {
                    //certificados.forEach(async function (certificado) {
                    while (i < certificados.length) {
                        //await delayExecution(certificado.id_usuario_ativ)
                        await AlterarAtividades(id_atividade, hora_max, hora_atividade, certificados[i], id_usuario)
                        await delayExecution(2000)
                        i++;
                    };
                });
            });
        }
    });
}

async function AlterarDeleteAtividadesdoTipo(id_atividade, id_usuario) {
    await con.query('SELECT hora_max, hora_atividade FROM tipo_atividade WHERE id_tipo_atividade = ?', [id_atividade], async function (err, result2) {
        if (err) throw err;

        var hora_max = result2[0].hora_max;
        var hora_atividade = result2[0].hora_atividade;
        var i = 0;
        var selectSql = "SELECT * FROM usuario_atividade WHERE id_atividade = ? AND status NOT IN ('Deferido', 'Indeferido') AND id_usuario = ?";
        await con.query(selectSql, [id_atividade, id_usuario], async function (err, certificados) {
            //certificados.forEach(async function (certificado) {
            while (i < certificados.length) {
                //await delayExecution(certificado.id_usuario_ativ)
                await AlterarAtividades(id_atividade, hora_max, hora_atividade, certificados[i], id_usuario)
                await delayExecution(1000)
                i++;
            };
        });
    });
}


// Apagar certificado
app.get('/apagar/:id_usuario_ativ', function (req, res) {
    if (req.session.id_usuario) {
        var id = req.params.id_usuario_ativ;
        id_usuario = req.session.id_usuario;
        var sql = "SELECT * FROM usuario_atividade WHERE id_usuario_ativ = ?";
        con.query(sql, id, function (err, result, fields) {
            if (err) throw err;
            if (result.length > 0) {
                const certificadoPath = path.join(__dirname, 'public/arquivos/', result[0]['certificado']);
                // if (fs.existsSync(certificadoPath)) {
                fs.unlink(certificadoPath, (err) => {
                    if (err) {
                        console.error('Erro para deletar o certificado', err);
                    } else {
                        var sqlDelete = "DELETE FROM usuario_atividade WHERE id_usuario_ativ = ?";
                        con.query(sqlDelete, id, async function (err, result2) {
                            if (err) throw err;
                            await delayExecution(1000)
                            await AlterarDeleteAtividadesdoTipo(result[0]['id_atividade'], id_usuario);
                            console.log("Número de dados deletados " + result2.affectedRows);

                            if (isAluno) {
                                await delayExecution(5000)
                                req.session.mensagem = "Certificado apagado";
                                res.redirect('/listar-horas-aluno');
                            } else {
                                await delayExecution(5000)
                                req.session.mensagem = "Certificado apagado";
                                res.redirect('/listagem');
                            }
                        });
                    }
                });
            } else {
                console.error('Erro');
            }
        });
    } else {
        res.redirect('/login');
    }
});

// Editar certificado
app.get('/editar/:id_usuario_ativ', function (req, res) {
    if (req.session.id_usuario) {
        var id_usuario_ativ = req.params.id_usuario_ativ;
        con.query('SELECT * FROM usuario_atividade WHERE id_usuario_ativ = ?', [id_usuario_ativ], function (err, result) {
            if (err) throw err;
            con.query('SELECT id_tipo_atividade, tipo_atividade FROM tipo_atividade', function (err, tipoAtividades) {
                if (err) throw err;
                var id_tipo_atividade_selecionado = result[0].id_atividade;
                res.render('edita-horas.ejs', {
                    dadosCertificado: result,
                    tipoAtividades: tipoAtividades,
                    selectedTipoAtividade: id_tipo_atividade_selecionado // Passa o ID do tipo de atividade selecionado
                });
            });
        });
    } else {
        res.redirect('/login')
    }
});

app.post('/editar/:id_usuario_ativ', function (req, res) {
    var id_usuario = req.session.id_usuario;
    var form = new formidable.IncomingForm();
    form.options.allowEmptyFiles = true; // permitir o envio opcional 
    form.options.minFileSize = 0; // permitir o envio opcional
    form.parse(req, (err, fields, files) => {
        if (err) throw err;
        var id_usuario_ativ = req.params.id_usuario_ativ;
        // Obter id_atividade com base no nome da atividade selecionada
        var id_atividade = fields['id_tipo_atividade'];
        con.query('SELECT hora_max, hora_atividade FROM tipo_atividade WHERE id_tipo_atividade = ?', [id_atividade], function (err, result) {
            if (err) throw err;
            var hora_max = result[0].hora_max;
            var hora_atividade = result[0].hora_atividade;
            con.query('SELECT SUM(ch_sugerida) as soma FROM `usuario_atividade` WHERE id_atividade = ? and status != "Indeferido" and id_usuario_ativ != ? AND id_usuario = ?', [id_atividade, id_usuario_ativ, id_usuario], function (err, result) {
                if (err) throw err;
                var soma = 0;
                if (result[0].soma)
                    soma = result[0].soma;

                var ch_sugerida = 0;
                var horas_enviadas = fields['ch_enviada'];
                var enviadas_soma = parseInt(horas_enviadas, 10) + parseInt(soma, 10);
                var atividade_soma = parseInt(hora_atividade, 10) + parseInt(soma, 10)
                if (horas_enviadas < hora_atividade) {
                    //console.log("horas_enviadas < hora_atividade")
                    if (enviadas_soma > hora_max) {
                        // console.log("horas_enviadas + soma > hora_max" + enviadas_soma)
                        ch_sugerida = hora_max - soma;
                    }
                    else {
                        // console.log("horas_enviadas + soma < hora_max")
                        ch_sugerida = horas_enviadas;
                    }
                } else {
                    // console.log("horas_enviadas > hora_atividade")
                    if (atividade_soma > hora_max) {
                        //console.log("hora_atividade + soma> hora_max")
                        ch_sugerida = hora_max - soma;
                    } else {
                        //console.log("hora_atividade + soma < hora_max")
                        ch_sugerida = hora_atividade;
                    }
                }
                console.log("Ch sugerida: " + ch_sugerida)
                if (files['certificado'][0]['originalFilename'].length !== 0) {

                    var oldpath = files.certificado[0].filepath;
                    var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
                    var nomeimg = hash + '.' + files.certificado[0].mimetype.split('/')[1];
                    var newpath = path.join(__dirname, 'public/arquivos/', nomeimg);

                    fs.rename(oldpath, newpath, function (err) {
                        if (err) throw err;
                    });

                    var sql = "UPDATE usuario_atividade SET nome_atividade = ?, ch_sugerida = ?, id_atividade = ?, certificado = ? WHERE id_usuario_ativ = ?"; //ch_deferida = ?
                    var values = [fields['nome_atividade'], ch_sugerida, id_atividade, nomeimg, id_usuario_ativ]; //fields['ch_deferida']

                } else {
                    var sql = "UPDATE usuario_atividade SET nome_atividade = ?, ch_sugerida = ?, id_atividade = ? WHERE id_usuario_ativ = ?"; //ch_deferida = ?
                    var values = [fields['nome_atividade'], ch_sugerida, id_atividade, id_usuario_ativ]; //fields['ch_deferida']
                }
                con.query(sql, values, async function (err, result) {
                    if (err) throw err;
                    await AlterarAtividadesdoTipo(id_usuario_ativ, id_usuario); //id
                    await delayExecution(2000);
                    console.log("Numero de registros alterados: " + result.affectedRows);
                    if (isAluno) {
                        req.session.mensagem = "Certificado alterado";
                        res.redirect('/listar-horas-aluno');
                    } else {
                        req.session.mensagem = "Certificado alterado";
                        res.redirect('/listagem');
                    }
                });
            });
        });
    });
});



app.get('/validar/:id_usuario_ativ', isAdm_Sec, function (req, res) {
    if (req.session.id_usuario) {
        var id = req.params.id_usuario_ativ;
        var selectSql = "SELECT id_usuario, ch_enviada ,ch_deferida, ch_sugerida, hora_max FROM usuario_atividade INNER JOIN tipo_atividade ON usuario_atividade.id_atividade = tipo_atividade.id_tipo_atividade WHERE id_usuario_ativ = ?";
        con.query(selectSql, id, function (err, result) {
            if (err) throw err;
            var chDeferida = result[0].ch_deferida;
            var chSugerida = result[0].ch_sugerida;
            var horaMax = result[0].hora_max;
            // Lidar com ch_deferida maior que ch_sugerida
            var horasSalvas = chSugerida;
            var updateSql = "UPDATE usuario_atividade SET status = 'Deferido', ch_deferida = ? WHERE id_usuario_ativ = ?";
            con.query(updateSql, [horasSalvas, id], function (err, result) {
                if (err) throw err;
                console.log("Certificado validado com sucesso!");
                // Atualizar horas restantes na sessão após a validação
                req.session.horasRestantes -= horasSalvas;
                req.session.mensagem = "Certificado validado";
                res.redirect('/listagem');
            });
        });
    } else {
        res.redirect('/login');
    }
});

app.post('/invalidar/:id_usuario_ativ', isAdm_Sec, async function (req, res) {
    if (req.session.id_usuario) {
        var id = req.params.id_usuario_ativ;
        var mensagem_indef = req.body.mensagem;
        var id_usuario = req.session.id_usuario;
        var updateSql = "UPDATE usuario_atividade SET status = 'Indeferido', mensagem = ?  WHERE id_usuario_ativ = ?";
        con.query(updateSql, [mensagem_indef, id], async function (err, result) {
            if (err) throw err;
            con.query("Select id_usuario from usuario_atividade where id_usuario_ativ = ?", [id], async function (err, result2) {
                await AlterarAtividadesdoTipo(id, result2[0].id_usuario);
                await delayExecution(5000)
                req.session.mensagem = "Certificado invalidado e mensagem salva";
                res.redirect('/listagem');
            });
        });
    } else {
        res.redirect('/login');
    }
});
//DICAS
app.get('/publicar', isAluno, function (req, res) {
    if (req.session.id_usuario) {
        res.render('postar.ejs');
    } else {
        res.redirect('/login');
    }
});

app.post('/publicar', function (req, res) {
    var id_usuario = req.session.id_usuario;
    var form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        var oldpath = files.imagem_post[0].filepath;
        var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
        var nomeimg = hash + '.' + files.imagem_post[0].mimetype.split('/')[1]
        var newpath = path.join(__dirname, 'public/imagens/posts/', nomeimg);
        fs.rename(oldpath, newpath, function (err) {
            if (err) throw err;
        });
        var sql = "INSERT INTO sugestao_horas (id_usuario, titulo_post, texto_post, imagem_post, status_revisao) VALUES ?";
        var values = [[id_usuario, fields['titulo_post'][0], fields['texto_post'][0], nomeimg, 'Pendente']];
        con.query(sql, [values], function (err, result) {
            if (err) throw err;
            console.log("Numero de registros inseridos: " + result.affectedRows);
            req.session.mensagem = "Post publicado com sucesso! Aguarde a validação";
            res.redirect('/posts');
        });
    });
});

app.get('/posts', function (req, res) {
    var perPage = 3
    var page = 0
    var id_usuario = req.session.id_usuario;
    var sql = "SELECT sugestao_horas.*, usuario.nome_usuario, usuario.foto_perfil FROM sugestao_horas JOIN usuario ON sugestao_horas.id_usuario = usuario.id_usuario";
    contagem = "SELECT COUNT(*) as numero FROM sugestao_horas";
    var mensagem = null;
    if (req.session.mensagem) {
        mensagem = req.session.mensagem;
        req.session.mensagem = null;
    }
    con.query(contagem, function (err, result2, fields) {
        if (err) throw err;
        con.query(sql, [perPage, page], function (err, result, fields) {
            if (err) throw err;
            pages = Math.ceil(result2[0]['numero'] / perPage)
            res.render('posts.ejs', { dadosPost: result, current: page + 1, pages: pages, id_usuario, mensagem: mensagem }) // usuario: usuario, id_usuario: id_usuario,
        });
    });
});

app.get('/posts/:page', function (req, res) {
    // if (req.session.id_usuario) {
    var perPage = 3;
    var page = parseInt(req.params.page) || 1; // Se não houver parâmetro de página, padrão para a primeira página
    var offset = (page - 1) * perPage; // Calcular o deslocamento com base no número da página
    var sql = "SELECT sugestao_horas.*, usuario.nome_usuario, usuario.foto_perfil FROM sugestao_horas JOIN usuario ON sugestao_horas.id_usuario = usuario.id_usuario LIMIT ? OFFSET ?";
    var countQuery = "SELECT COUNT(*) as numero FROM sugestao_horas"; // Correção de erro de digitação
    con.query(countQuery, function (err, result2, fields) {
        if (err) throw err;
        con.query(sql, [perPage, offset], function (err, result, fields) {
            if (err) throw err;
            var totalPosts = result2[0]['numero'];
            var totalPages = Math.ceil(totalPosts / perPage);
            res.render('posts.ejs', { dadosPost: result, current: page, pages: totalPages, mensagem: req.session.mensagem || '' });
            req.session.mensagem = null;
        });
    });
});

app.get('/editar-post/:id_post', function (req, res) {
    if (req.session.id_usuario) {
        var sql = "SELECT * FROM sugestao_horas WHERE id_post= ?"; //MUDAR ID ERRADO
        var id_post = req.params.id_post;
        con.query(sql, id_post, function (err, result, fields) {
            if (err) throw err;
            console.log(result)
            res.render('edita-post.ejs', { id_post: id_post, dadosPost: result, imagem_post: result[0].imagem_post });
        });
    } else {
        res.redirect('/login');
    }
});
app.post('/editar-post/:id_post', function (req, res) {
    var form = new formidable.IncomingForm();
    form.options.allowEmptyFiles = true; // permitir o envio opcional 
    form.options.minFileSize = 0;   // permitir o envio opcional
    form.parse(req, (err, fields, files) => {
        if (err) throw err;
        if (files['imagem_post'][0]['originalFilename'].length !== 0) {
            // Verificar se há um novo arquivo de imagem enviado
            var oldpath = files.imagem_post[0].filepath;
            var hash = crypto.createHash('md5').update(Date.now().toString()).digest('hex');
            nomeimg = hash + '.' + files.imagem_post[0].mimetype.split('/')[1]
            var newpath = path.join(__dirname, 'public/imagens/posts/', nomeimg);
            fs.rename(oldpath, newpath, function (err) {
                if (err) throw err;
            });
            var id_post = req.params.id_post;
            var sql = "UPDATE sugestao_horas SET titulo_post = ?, texto_post = ?, imagem_post = ? WHERE id_post = ?";
            var values = [fields['titulo_post'], fields['texto_post'], nomeimg, id_post];
        } else {
            // Se não houver novo arquivo de imagem enviado, use o valor existente do campo imagem_post
            var id_post = req.params.id_post;
            var sql = "UPDATE sugestao_horas SET titulo_post = ?, texto_post = ? WHERE id_post = ?";
            var values = [fields['titulo_post'], fields['texto_post'], id_post];
        }
        con.query(sql, values, function (err, result) {
            if (err) throw err;
            console.log("Numero de registros alterados: " + result.affectedRows);
            req.session.mensagem = "Publicação alterada."
            res.redirect('/posts');
        });
        // }
    });
});

app.get('/apagar-post/:id_post', function (req, res) {
    if (req.session.id_usuario) {
        var id = req.params.id_post;
        var sql = "SELECT * FROM sugestao_horas where id_post=?";
        con.query(sql, id, function (err, result, fields) {
            if (err) throw err;
            const img = path.join(__dirname, 'public/imagens/posts/', result[0]['imagem_post']); // 'public/imagens/'
            fs.unlink(img, (err) => {
            });
        });
        var deletar = "DELETE FROM sugestao_horas WHERE id_post= ?";
        con.query(deletar, id, function (err, result) {
            if (err) throw err;
            console.log("Numero de registros Apagados: " + result.affectedRows);
        });
        req.session.mensagem = "Post apagado com sucesso!";
        res.redirect('/posts');
    } else {
        res.redirect('/login');
    }
});

app.get('/validar-post/:id_post', isAdm_Sec, function (req, res) {
    if (req.session.id_usuario) {
        var id = req.params.id_post;
        var sql = "UPDATE sugestao_horas SET status_revisao = 'Válido' WHERE id_post = ?";
        con.query(sql, id, function (err, result) {
            if (err) throw err;
            req.session.mensagem = "Status do post validado com sucesso!";
            res.redirect('/posts');
        });
    } else {
        res.redirect('/login');
    }
});

app.get('/invalidar-post/:id_post', isAdm_Sec, function (req, res) {
    if (req.session.id_usuario) {
        var id = req.params.id_post;
        var updateSql = "UPDATE sugestao_horas SET status_revisao = 'Inválido' WHERE id_post = ?";
        con.query(updateSql, [id], function (err, result) {
            if (err) throw err;
            req.session.mensagem = "Status do post invalidado com sucesso!";
            res.redirect('/posts');
        });
    } else {
        res.redirect('/login');
    }
});

//Listagem de usuários (com paginação)
app.get('/usuarios', isAdmin, function (req, res) {
    if (req.session.id_usuario) {
        var perPage = 3
        var page = 0
        var usuario = req.session.usuario
        var id_usuario = req.session.id_usuario
        var sql = "SELECT * FROM usuario ORDER BY id_usuario ASC LIMIT ? OFFSET ?"
        contagem = "SELECT COUNT(*) as numero FROM usuario";
        var mensagem = null;
        if (req.session.mensagem) {
            mensagem = req.session.mensagem;
            req.session.mensagem = null;
        }
        con.query(contagem, function (err, result2, fields) {
            if (err) throw err;
            con.query(sql, [perPage, page], function (err, result, fields) {
                if (err) throw err;
                pages = Math.ceil(result2[0]['numero'] / perPage)
                res.render('usuarios.ejs', { dadosUsuarios: result, usuario: usuario, id_usuario: id_usuario, current: page + 1, pages: pages, mensagem: mensagem })
            });
        });
    }
    else {
        res.redirect('/login');
    }
});

app.get('/usuarios/:page', isAdmin, function (req, res) { //isAdm_Sec,
    if (req.session.id_usuario) {
        var perPage = 3;
        var page = parseInt(req.params.page) || 1; // Se não houver parâmetro de página, padrão para a primeira página
        var offset = (page - 1) * perPage; // Calcular o deslocamento com base no número da página
        var usuario = req.session.usuario;
        var id_usuario = req.session.id_usuario;
        var sql = "SELECT * FROM usuario ORDER BY id_usuario ASC LIMIT ? OFFSET ?";
        var countQuery = "SELECT COUNT(*) as numero FROM usuario";
        con.query(countQuery, function (err, result2, fields) {
            if (err) throw err;
            con.query(sql, [perPage, offset], function (err, result, fields) {
                if (err) throw err;
                var totalUsers = result2[0]['numero'];
                var totalPages = Math.ceil(totalUsers / perPage);
                res.render('usuarios.ejs', {
                    dadosUsuarios: result,
                    usuario: usuario,
                    id_usuario: id_usuario,
                    current: page,
                    pages: totalPages,
                    mensagem: req.session.mensagem || ''
                });
                req.session.mensagem = null;
            });
        });
    } else {
        req.session.erro = "É necessário fazer login para acessar essa página";
        res.redirect('/login');
    }
});



app.get('/excluir-usuario/:id_usuario', isAdmin, function (req, res) {
    if (req.session.id_usuario) {
        var id = req.params.id_usuario;

        // Primeiro, deletamos as conversas relacionadas ao usuário
        var sqlDeleteChat = "DELETE FROM chat WHERE enviou_id = ? OR recebeu_id = ?";
        con.query(sqlDeleteChat, [id, id], function (err, result) {
            if (err) throw err;
            console.log("Número de conversas apagadas: " + result.affectedRows);

            // Depois, deletamos os posts relacionados ao usuário
            var sqlDeletePosts = "DELETE FROM sugestao_horas WHERE id_usuario = ?";
            con.query(sqlDeletePosts, id, function (err, result) {
                if (err) throw err;
                console.log("Número de posts apagados: " + result.affectedRows);

                // Em seguida, deletamos as atividades relacionadas ao usuário
                var sqlDeleteUsuarioAtividade = "DELETE FROM usuario_atividade WHERE id_usuario = ?";
                con.query(sqlDeleteUsuarioAtividade, id, function (err, result) {
                    if (err) throw err;
                    console.log("Número de atividades de usuário apagadas: " + result.affectedRows);

                    // Finalmente, podemos tentar deletar o usuário
                    var sqlDeleteUsuario = "DELETE FROM usuario WHERE id_usuario = ?";
                    con.query(sqlDeleteUsuario, id, function (err, result) {
                        if (err) {
                            console.error("Erro ao excluir o usuário:", err);
                            res.redirect('/usuarios'); // Pode querer tratar erros de forma diferente
                        } else {
                            console.log("Número de registros de usuários apagados: " + result.affectedRows);
                            req.session.mensagem = "Usuário excluído";
                            res.redirect('/usuarios');
                        }
                    });
                });
            });
        });
    } else {
        res.redirect('/login');
    }
});

// chat
app.get('/chat', function (req, res) {
    if (!req.session.id_usuario) {
        res.redirect('/login');
    } else {
        var usuario = req.session.usuario
        var id_usuario = req.session.id_usuario
        var imagem = req.session.foto
        var sql = "SELECT * FROM usuario WHERE tipo_usuario = ? " //ORDER BY id_usuario
        con.query(sql, [2], function (err, result, fields) {
            if (err) throw err;
            req.session.amigoid = result[0]['id_usuario']
            var amigoid = result[0]['id_usuario']
            res.render('chat.ejs', { imagem: imagem, usuario: usuario, id_usuario: id_usuario, amigoid: amigoid })
        });
    }
});
app.post('/chat', function (req, res) {
    if (!req.session.id_usuario) {
        req.session.erro = "É necessário fazer login para acessar essa página"
        res.redirect('/login');
    } else {
        var usuario = req.session.usuario
        var id_usuario = req.session.id_usuario
        var imagem = req.session.foto
        req.session.amigoid = req.body['id']
        var amigoid = req.body['id']
        res.render('chat.ejs', { imagem: imagem, usuario: usuario, id_usuario: id_usuario, amigoid: amigoid })

    }
});
app.post('/recebemensagens', function (req, res) {
    usuario_logado = req.session.id_usuario;
    amigo = req.session.amigoid;
    var sql = "INSERT INTO chat (enviou_id, recebeu_id, mensagem, lida) VALUES ?";
    var values = [
        [usuario_logado, amigo, req.body['mensagem'], 0]
    ];
    con.query(sql, [values], function (err, result) {
        if (err) throw err;
        console.log("Numero de registros inseridos: " + result.affectedRows);
    });
    res.send("Mensagem salva");
});

app.post('/buscamensagens', function (req, res) {
    usuario_logado = req.session.id_usuario;
    foto_logado = req.session.foto;
    amigo = req.session.amigoid;
    retorno = ""
    var sql = "SELECT * FROM usuario WHERE id_usuario = ? " //ORDER BY id_usuario
    con.query(sql, amigo, function (err, result, fields) {
        if (err) throw err;
        foto_amigo = result[0]['foto_perfil']; //imagem
        valores = [usuario_logado, amigo, amigo, usuario_logado]
        sql2 = "SELECT * FROM chat WHERE (enviou_id=? && recebeu_id= ?) or (enviou_id=? && recebeu_id= ?) ORDER BY id  LIMIT 100;";
        con.query(sql2, valores, function (err, mensagens, fields) {
            if (err) throw err;
            mensagens.forEach(function (dados) {
                moment.locale("pt-br");
                // var data = moment().format("DD-MM-YYYY kk:mm")
                var data = moment(dados['data']).format("DD-MM-YYYY kk:mm");
                if (usuario_logado == dados['enviou_id']) {
                    retorno = retorno + "<div class='media media-chat media-chat-reverse'>";
                    if (foto_logado && foto_logado.includes("googleusercontent")) {
                        retorno = retorno + "<img class='avatar' src= " + foto_logado + ">";
                    } else {
                        retorno = retorno + "<img class='avatar' src=imagens/usuario/" + foto_logado + ">";
                    }
                    retorno = retorno + "<div class='media-body'>" +
                        "<p>" + dados['mensagem'] + "<br>" + data + "</p>" +
                        "</div>" +
                        "</div>" +
                        "<div class='media media-meta-day'> </div>"
                } else {
                    retorno = retorno + "<div class='media media-chat'>";
                    if (foto_amigo && foto_amigo.includes("googleusercontent")) {
                        retorno = retorno + "<img class='avatar' src= " + foto_amigo + ">";
                    } else {
                        retorno = retorno + "<img class='avatar' src=imagens/usuario/" + foto_amigo + ">";
                    }
                    retorno = retorno + "<div class='media-body'>" +
                        "<p>" + dados['mensagem'] + "<br>" + data + "</p>" +
                        "</div>" +
                        "</div>" +
                        "<div class='media media-meta-day'> </div>"
                }
            })
            sql3 = "UPDATE chat SET lida=1 WHERE (enviou_id=? && recebeu_id= ?);";
            valores2 = [amigo, usuario_logado]
            con.query(sql3, valores2, function (err, mensagens, fields) {
                if (err) throw err;
            });
            res.send(JSON.stringify(retorno));
        });
    })
});

app.post('/busca-nao-lidas', function (req, res) {
    usuario_logado = req.session.id_usuario;
    foto_logado = req.session.foto;
    amigo = req.session.amigoid;
    retorno = ""
    var sql = "SELECT * FROM usuario WHERE id_usuario = ? " //ORDER BY id_usuario
    con.query(sql, amigo, function (err, result, fields) {
        if (err) throw err;
        foto_amigo = result[0]['foto_perfil']; //imagem
        valores = [amigo, usuario_logado]
        sql2 = "SELECT * FROM chat WHERE (enviou_id=? && recebeu_id= ?) && lida=0 ORDER BY id  LIMIT 100;";
        con.query(sql2, valores, function (err, mensagens, fields) {
            if (err) throw err;
            mensagens.forEach(function (dados) {
                moment.locale("pt-br");
                var data = moment().format("DD-MM-YYYY kk:mm")
                if (usuario_logado == dados['enviou_id']) {

                    retorno = retorno + "<div class='media media-chat media-chat-reverse'>";
                    if (foto_amigo && foto_amigo.includes("googleusercontent")) {
                        retorno = retorno + "<img class='avatar' src= " + foto_amigo + ">";
                    } else {
                        retorno = retorno + "<img class='avatar' src=imagens/usuario/" + foto_amigo + ">";
                    }
                    retorno = retorno +
                        "<div class='media-body'>" +
                        "<p>" + dados['mensagem'] + "<br>" + data + "</p>" +
                        "</div>" +
                        "</div>" +
                        "<div class='media media-meta-day'> </div>"
                } else {
                    retorno = retorno + "<div class='media media-chat'>";
                    if (foto_amigo && foto_amigo.includes("googleusercontent")) {
                        retorno = retorno + "<img class='avatar' src= " + foto_amigo + ">";
                    } else {
                        retorno = retorno + "<img class='avatar' src=imagens/usuario/" + foto_amigo + ">";
                    }
                    retorno = retorno +
                        "<div class='media-body'>" +
                        "<p>" + dados['mensagem'] + "<br>" + data + "</p>" +
                        "</div>" +
                        "</div>" +
                        "<div class='media media-meta-day'> </div>"
                }
            })
            sql3 = "UPDATE chat SET lida=1 WHERE (enviou_id=? && recebeu_id= ?);";
            valores2 = [amigo, usuario_logado]
            con.query(sql3, valores2, function (err, mensagens, fields) {
                if (err) throw err;
            });
            res.send(JSON.stringify(retorno));
        });
    })
});

//Listagem de usuários (com paginação)
app.get('/resultado', isSecretaria, function (req, res) {
    if (req.session.id_usuario) {
        var perPage = 3;
        var page = 0;
        var usuario = req.session.usuario;
        var id_usuario = req.session.id_usuario;
        var sql = "SELECT * FROM usuario WHERE tipo_usuario = 1"; //ORDER BY id_usuario ASC LIMIT ? OFFSET ?
        contagem = "SELECT COUNT(*) as numero FROM usuario";
        con.query(contagem, function (err, result2, fields) {
            if (err) throw err;
            con.query(sql, [perPage, page], function (err, result, fields) {
                if (err) throw err;
                // Mapear os resultados para calcular a carga horária pendente de cada usuário
                var promises = result.map(function (user) {
                    return new Promise(function (resolve, reject) {
                        calcularHorasRestantesDoUsuario(req.session.id_curso ,user.id_usuario, function (horasRestantes) {
                            user.horasRestantes = horasRestantes;
                            resolve(user);
                        });
                    });
                });
                // Aguardar todas as promessas serem resolvidas antes de renderizar a página
                Promise.all(promises).then(function (usersWithCH) {
                    pages = Math.ceil(result2[0]['numero'] / perPage);
                    res.render('resultado.ejs', { dadosUsuarios: usersWithCH, usuario: usuario, id_usuario: id_usuario, current: page + 1, pages: pages });
                });
            });
        });
    } else {
        res.redirect('/login');
    }
});

app.get('/resultado/:page', isSecretaria, function (req, res) {
    if (req.session.id_usuario) {
        var perPage = 5
        var page = parseInt(req.params.page) - 1
        page = page * perPage
        var usuario = req.session.usuario
        var id_usuario = req.session.id_usuario
        var sql = "SELECT * FROM usuario  WHERE tipo_usuario = 0 ORDER BY id_usuario ASC LIMIT ? OFFSET ?"
        contagem = "SELECT COUNT(*) as numero FROM usuario";
        con.query(contagem, function (err, result2, fields) {
            if (err) throw err;
            con.query(sql, [perPage, page], function (err, result, fields) {
                if (err) throw err;
                pages = Math.ceil(result2[0]['numero'] / perPage)
                res.render('resultado.ejs', { dadosUsuarios: result, usuario: usuario, id_usuario: id_usuario, current: page + 1, pages: pages })
            });
        });
    } else {
        res.redirect('/login');
    }
});

// Servidor
app.listen(3000, function () {
    console.log("Servidor Escutando na porta 3000");
});